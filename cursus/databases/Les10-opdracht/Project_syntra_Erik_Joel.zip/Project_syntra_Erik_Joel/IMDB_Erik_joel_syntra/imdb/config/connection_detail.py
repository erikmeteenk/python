
sql_details = {
        'host': 'localhost',
        'user': 'root',
        'password': 'Raidersofthelostarc1',
        'database': 'imdb'    # put this in comment when you run create_tables_imdb method
}
